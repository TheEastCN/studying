# -*- coding:utf-8 -*-

import sys
import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

from core import logger
from core import getter
from config import settings
from core import md5

logger_obj = logger.logger("transaction")


def check_out(money, username, passwd, username_in):
    bank_data = getter.json_data_get(settings.BANK_FILE)
    # pay_data = getter.json_data_get(settings.PAY_FILE)
    if bank_data[username]["passwd"] == md5.hash_md5(passwd):
        if money < bank_data[username]["balance"]:
            bank_data[username]["balance"] -= money
            bank_data[username_in]["balance"] += money
            getter.json_data_put(bank_data, settings.BANK_FILE)
            logger_obj.info('%s扣款成功' % username)
            logger_obj.info('%s入账成功' % username_in)
        else:
            logger_obj.error('%s账户余额不足' % username)
    else:
        logger_obj.error('%s支付密码错误' % username)


def with_draw(money, username):
    bank_data = getter.json_data_get(settings.BANK_FILE)
    
    card_balance = bank_data[username]["balance"]
    
    cash_adv_money = money * 1.05
    if cash_adv_money <= card_balance:
        service_charge = money * 0.05
        bank_data[username]["balance"] = card_balance - cash_adv_money
        getter.json_data_put(bank_data, settings.BANK_FILE)
        logger_obj.info("%s 取现%s,手续费%s" % (username, money, service_charge))
    else:
        logger_obj.info("余额不足")


def repay(username):
    bank_data = getter.json_data_get(settings.BANK_FILE)
    debt = bank_data[username]["limit"] - bank_data[username]["balance"]
    print("欠款：%s" % debt)
    while True:
        repay_money = input("请输入还款金额:").strip()
        if not repay_money:
            continue
        elif repay_money.isdigit() and int(repay_money) > 0:
            bank_data[username]["balance"] += int(repay_money)
            getter.json_data_put(bank_data, settings.BANK_FILE)
            debt = bank_data[username]["limit"] - bank_data[username]["balance"]
            if debt == 0:
                logger_obj.info("欠款已还清")
                break
            else:
                logger_obj.info("已还金额：%s,欠款:%s" % (repay_money, debt))
                break
        else:
            logger_obj.error("输入额度错误")



