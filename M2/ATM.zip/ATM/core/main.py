# -*- coding:utf-8 -*-
import os
import sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

from core import logger
from core import getter
from config import settings
from core import md5


main_menu = {1:"购物车",2:"ATM"}
atm_menu = {1:"信息查询",2:"还款",3:"取现",4:"账户新增",5:"增额",6:"账户冻结",7:"转账" }