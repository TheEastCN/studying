# -*- coding:utf-8 -*-

import hashlib
import os
import sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
print(BASE_DIR)
sys.path.append(BASE_DIR)

from core import logger
from core import getter
from config import settings

def hash_md5(str):

    md5 = hashlib.md5()
    md5.update(bytes(str, encoding='utf-8'))

    return md5.hexdigest()


def diff_md5(account, passwd,file_name):
    md5_new = hash_md5(passwd)
    data = getter.json_data_get(file_name)
    if data[account]['password'] == md5_new:
        return True
    else:
        return  False

