# -*- coding:utf-8 -*-

import os
import sys
import time
import json
import logging
from core import logger
from config import settings

user_status = False


def login(func):

    def inner(*args, **kwargs):
        global user_status
        count = 0
        if not user_status:

            while count < 3:
                user_input = input("user:").strip()
                passwd_input = input("passwd:").strip()

                file_name = "%s/account/%s.json" % (
                    settings.BASE_DIR, user_input)
                if os.path.exists(file_name):
                    username = file_name.split(".")[0]
                    data = json_data(file_name)
                    passwd = data[username]['password']
                    if user_input == username and passwd_input == passwd:
                        local_time = time.strftime(
                            "%Y-%m-%d", time.localtime())

                        if data["expire_date"] < local_time and data["status"] == 0:
                            user_status = True
                            print("user loggin")
                            func(*args, **kwargs)
                    else:
                        print('user/passwd input Error')
                count += 1

        else:
            print('user loggin')
            func(*args, **kwargs)
    return inner


def pay_author(account_no, pay_passwd):

    file_name = "%s/account/%s.json" % (settings.BASE_DIR, account_no)
    count = 0
    if os.path.exists(file_name):
        while count < 3:
            account_no_file = file_name.split('.')[0]
            data = json_data(file_name)
            pay_passwd_file = data["password"]

            if account_no == account_no_file and pay_passwd == pay_passwd_file:
                print('Payment password verified successfully')

            else:
                print(
                    "Payment password error.The account will be locked after 3 errors!")
            count += 1
    else:
        print('Account does not exist')


def json_data(file_name):
    with open(file_name, "r+", encoding="utf-8") as login_file:
        data = json.dump(login_file)
    return data
