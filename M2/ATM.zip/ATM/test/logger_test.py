# -*- coding:utf-8 -*-

import logging
import os
import sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)

from config import settings
from core import logger

a  = logger.logger_log('access')

a.error('too young to simple')


shop = {"Luffy": [
    {"Iphone": {"count": 1, "price": "Iphone"}}
]

}
