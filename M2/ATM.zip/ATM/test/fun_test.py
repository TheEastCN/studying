# -*- coding:utf-8 -*-
import os,json,sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(BASE_DIR)
data ={
  "Luffy": {
      "name1":{"expire_date": "2021-01-01", "id": 1234, "status": 0, "pay_day": 22, "password": "900150983cd24fb0d6963f7d28e17f72"},
"name2":{"expire_date": "2021-01-01", "id": 1234, "status": 0, "pay_day": 22, "password": "900150983cd24fb0d6963f7d28e17f72"}
},
  "Zoro" : {"expire_date": "2021-01-01", "id": 1235, "status": 0, "pay_day": 22, "password": "900150983cd24fb0d6963f7d28e17f72"},
  "Namei": {"expire_date": "2021-01-01", "id": 1236, "status": 0, "pay_day": 22, "password": "900150983cd24fb0d6963f7d28e17f72"}
}

USER_MOD = {"account":str, "passwd":str, "status":int,"cardno":str, "limit":int, "balance":int}
# USER_FILE = "%s/%s/%s"%(BASE_DIR,"account","luffy.json" )
# with open(USER_FILE,'r') as f:
#     f_data = json.load(f)

# for i in data:
#     print(data[i])
print(USER_MOD.keys())
for i in USER_MOD:
    
    if USER_MOD[i] == int:
        print("int")
    

# if good_buy['name'] in shop_cart[username].keys():
#     count = shop_cart[username][good_buy['name']]["count"] + 1
#     shop_cart[username][good_buy['name']]["count"] = count
